# Detection_mamamoge > 2023-04-06 10:48pm
https://universe.roboflow.com/company-only-me/detection_mamamoge

Provided by a Roboflow user
License: CC BY 4.0

